"""
    Function.py
    Marisa Loraas
    CSE 324: Principles of Programming Languages
    Project 2: LISP Interpreter
    Due: 4/19/2020
"""
import lisp_interpreter
import Environment


class Function(object):
    def __init__(self, params, body, environment):
        """Function Declaration"""
        self.params, self.body, self.environment = params, body, environment

    def __call__(self, *args):
        """Executes function being referenced"""
        old_params = self.params
        old_body = self.body
        old_environment = self.environment
        new_args = list()
        function = list()
        sub_args = list()
        sub_params = list()
        for arg in args:
            if arg in self.environment:
                new_args.append(self.environment.find(arg)[arg])
            else:
                new_args.append(arg)
        i = 0
        for item in self.body:
            if isinstance(item, list):
                sub_params = (self.body[i][1:])
                j = 0
                for subitem in self.body[i]:
                    if isinstance(subitem, int):
                        item[j] = str(subitem)
                    j += 1
                self.body[i] = '(' + ' '.join(item) + ')'
                function.append(i)

            elif isinstance(item, int):
                self.body[i] = str(item)
            i += 1
        self.body = '( ' + ' '.join(self.body) + ' )'
        self.body = Environment.parse(self.body)
        i = 0
        j = 0
        for i in function:
            if isinstance(self.body[i], list):
                function = self.environment.find(self.body[i][0])[self.body[i][0]]
                if len(new_args) == 1 and len(args) == 1:
                    self.body[i] = lisp_interpreter.evaluate_constructs(function(new_args[0], new_args[0]), Environment.Environment(sub_params, *sub_args, self.environment))
                else:
                    for param in self.params:
                        if param in sub_params:
                            sub_args.append(new_args[j])
                            new_args.remove(new_args[j])
                        j += 1
                    self.body[i] = lisp_interpreter.evaluate_constructs(function(*sub_args), Environment.Environment(sub_params, *sub_args, self.environment))
                    new_args.append(self.body[i])

        body = lisp_interpreter.evaluate_constructs(self.body, self.environment)
        new_body = lisp_interpreter.evaluate_constructs(self.body[0], self.environment)
        if isinstance(body, int) and len(self.params) != 2:
            self.__init__(old_params, old_body, old_environment)
            return body
        else:
            if len(new_args) == 1 and len(args) == 1:
                ans = lisp_interpreter.evaluate_constructs(new_body(new_args[0], new_args[0]), Environment.Environment(self.params, args[0], self.environment))
                self.__init__(old_params, old_body, old_environment)
                return ans
            else:
                ans = lisp_interpreter.evaluate_constructs(new_body(*new_args), Environment.Environment(self.params, *args, self.environment))
                self.__init__(old_params, old_body, old_environment)
                return ans

