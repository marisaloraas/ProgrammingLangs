"""
    lisp_interpreter.py
    Marisa Loraas
    CSE 324: Principles of Programming Languages
    Project 2: LISP Interpreter
    Due: 4/19/2020
"""

import Environment
import Function


def evaluate_constructs(expression, env):
    """ Evaluates a given expression after the lexical analysis and
        syntactic analysis phase. This is where the LISP constructs
        are implemented"""
    while True:
        # Variable Reference
        if isinstance(expression, str):
            return env.find(expression)[expression]
        # Constant Literal
        elif not isinstance(expression, list):
            return expression
        elif len(expression) == 0:
            return -1
        elif isinstance(expression, list) and len(expression) == 1:
            if expression[0] in env:
                return env.find(expression[0])[expression[0]]
            else:
                return expression[0]
        else:
                (first, *args) = expression
        # Quotation
        if expression[0] == "'":
            (_,literal) = expression
            return literal
        # Conditional
        elif expression[0] == 'if':
            i = 0
            for item in expression[1]:
                if isinstance(item, list):
                    expression[1][i] = evaluate_constructs(expression[1][i], env)
                i += 1
            if evaluate_constructs(expression[1], env):
                temp = evaluate_constructs(expression[2], env)
            else:
                temp = evaluate_constructs(expression[3], env)
            return temp
        elif expression[0] == 'cons':
            i = 0
            for item in expression:
                if item == "'":
                    expression.remove(item)
                elif item[0] == "'":
                    expression[i] = item.replace("'", '')
                i += 1
            return Environment.cons(expression[1], expression[2])
        # Variable Definition
        elif expression[0] == 'define':
            variable = expression[1]
            exp = expression[2:]
            if len(exp) == 1:
                for item in exp:
                    if isinstance(item, list):
                        exp = item
            if isinstance(exp, list) and exp[0] != "'":
                env[variable] = evaluate_constructs(evaluate_constructs(exp, env), env)
            elif exp[0] == "'":
                env[variable] = evaluate_constructs(exp, env)
            else:
                env[variable] = evaluate_constructs(exp, env)
            return env[variable]
            # Lambda Expression
        elif expression[0] == 'lambda':
            (_, params, body) = expression
            return Function.Function(params, body, env)
        # assignment
        elif expression[0] == 'set!':
            (_, variable, exp) = expression
            env.find(variable)[variable] = evaluate_constructs(exp, env)
            return env.find(variable)[variable]
        # Function Definition/Declaration
        elif expression[0] == 'defun':
            (_, function_name, params, body) = expression
            Environment.environment_functions(function_name, params, body, env)
            return function_name
        #Function call
        elif isinstance(env[expression[0]], Function.Function):
            (_, *args) = expression

            all_args = list()
            proc = env.find(str(expression[0]))[str(expression[0])]
            for arg1 in args:
                all_args.append(evaluate_constructs(arg1, env))
            return proc(*args)
        else:
            if expression[0] in env:
                i = 0
                new_args_list = list()
                for arg in args:
                    i += 1
                    if isinstance(arg, list):
                        arg = to_lisp(arg)
                        temp = ''.join(arg)
                        new_arg = evaluate_constructs(Environment.parse(temp), env)
                        new_args_list.append(new_arg)
                    else:
                        if arg in env:
                            arg = env.find(arg)[arg]
                        new_args_list.append(arg)
                return env.find(expression[0])[expression[0]](*new_args_list)
            else:
                return None


def to_lisp(expression):
    """Turns a returned expression back into LISP format"""
    if isinstance(expression, list):
        return '(' + ' '.join(map(to_lisp, expression)) + ')'
    else:
        if isinstance(expression, bool):
            if expression == True:
                return 'T'
            elif expression == False:
                return 'F'
        elif expression == -1:
            return 'NIL'
        else:
            return str(expression)


def main():
    print("Welcome to the fancy new Prompt LISP INTERPRETER\n")
    print("Type in LISP commmands: \n")
    # save expressions, output until user quits, put output in another file

    env = Environment.make_environment()

    output = open('output.txt', 'w')
    while True:
        expression = input(">")
        if expression == '(quit)':
            print('>Goodbye')
            print('EOF', file=output)
            break
        if expression[0] == "'":
            expression = '(' + expression + ')'
        input_eval = evaluate_constructs(Environment.parse(expression), env)
        if input_eval is not None:
            print(to_lisp(input_eval))
            print(to_lisp(input_eval), file=output)
    output.close()


if __name__ == '__main__':
    main()
