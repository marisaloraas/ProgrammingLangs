"""
    Environment.py
    Marisa Loraas
    CSE 324: Principles of Programming Languages
    Project 2: LISP Interpreter
    Due: 4/19/2020
"""
import operator
import math
import Function


class Environment(dict):
    def __init__(self, params=(), *args, outer=None):
        """Initialization for Environment"""
        super().__init__()
        self.update(zip(params, args))
        self.outer = outer

    def find(self, variable):
        """Allows to find if a variable is already in the
        created LISP environment"""
        if variable in self:
            return self
        else:
            return self.outer.find(variable)


def cons(x, y):
    """defines cons operator in LISP"""
    return [x] + y


def environment_functions(name, params, body, env):
    """Adds a new Function into the Environment"""
    index_array = []
    key_array = []
    i = 0
    for par in params:
        index_array.append(i)
        i += 1
    for par in params:
        key_array.append(str(par))
    env.update(list(zip(key_array, index_array)))
    env.update({str(name): Function.Function})
    env[str(name)] = Function.Function(params, body, env)


def make_environment():
    """Implements all the necessary pre-defined
    operators and functions for LISP"""
    env = Environment()
    env.update({
        '+': operator.add,
        '-': operator.sub,
        '*': operator.mul,
        '/': operator.truediv,
        'car': lambda x: x[0],
        'cdr': lambda x: x[1:],
        '>': operator.gt,
        '<': operator.lt,
        '=': operator.eq,
        '<=': operator.le,
        '>=': operator.ge,
        '!=': operator.ne,
        'and': operator.and_,
        'or': operator.or_,
        'not': operator.not_,
        'sqrt': math.sqrt,
        'pow': math.pow,
        'exp': lambda x: math.pow(math.e, x),
        'cons': cons,
        # 'lambda': NOT Implemented Here
    })
    env.update(vars(math))
    return env


def get_tokens(char_input):
    """Lexical analysis phase: input string is broken into
        a sequence of tokens"""
    return char_input.replace('(', ' ( ').replace(')', ' ) ').split()


def parse(expression):
    """Initiates all analysis phases of token parsing"""
    tokens = get_tokens(expression)
    return evaluate_tokens(tokens)


def atom(token):
    """"Initializes tokens that are atomic variables"""
    if token == "T":
        return True
    elif token == "F":
        return False
    elif token == 'NIL':
        return -1
    else:
        try:
            return int(token)
        except ValueError:
            try:
                return str(token)
            except ValueError:
                return None


def evaluate_tokens(tokens):
    """Syntactic analysis phase: tokens are assembled
    into a syntax tree"""
    left_paren = []
    if len(tokens) == 0:
        raise SyntaxError("Error in parsed token evaluation\n")
    else:
        temp = tokens.pop(0)
        if ')' == temp:
            raise SyntaxError("Unexpected ) in stack")
        elif '(' == temp:
            while tokens[0] != ')':
                left_paren.append(evaluate_tokens(tokens))
            tokens.pop(0)
            return left_paren
        else:
            if temp == 'NIL':
                return False
            else:
                return atom(temp)
